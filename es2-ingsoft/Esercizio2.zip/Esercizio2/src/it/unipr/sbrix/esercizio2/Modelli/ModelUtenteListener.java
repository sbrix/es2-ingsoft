package it.unipr.sbrix.esercizio2.Modelli;

import java.util.EventListener;

public interface ModelUtenteListener extends EventListener{
	public void myEventOccurred(ModelUtentiEvent evt);

}
