package it.unipr.sbrix.esercizio2.Modelli;

public interface InitModel {
	void initFromFile();

	void initModel();

}
