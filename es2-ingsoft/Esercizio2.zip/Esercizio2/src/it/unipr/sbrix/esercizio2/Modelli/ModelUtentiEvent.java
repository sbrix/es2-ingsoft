package it.unipr.sbrix.esercizio2.Modelli;

import java.util.EventObject;

public class ModelUtentiEvent extends EventObject {

	public ModelUtentiEvent(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -1744191456059967144L;

	

	

}
